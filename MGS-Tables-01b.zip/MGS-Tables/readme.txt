=== MGS-Tables ===
Tags: CSV, Google Drive, Tablas
Requires at least: 4.0  
Tested up to: 4.7.2
Stable tag: 0.1.b

MGS Tables permite crear tablas de forma rápida y dinámicas.

== Description ==
Importa archivos CSV y crea tablas

= Version 0.1.b =
* Lanzamiento