<?
class MGS_Tables_Builder_Admin {
	public function __construct(){
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
	}
	
	function admin_menu(){
		$configuracion = add_menu_page( 'MGS Tables', 'MGS Tables', 'manage_options', 'mgs-tables-config', array( $this, 'configuracion' ), 'dashicons-editor-table', '2.111112' );
		add_action( 'admin_print_scripts-'.$configuracion, array( $this, 'mgs_tables_admin_scripts' ) );
	}
	
	public function configuracion(){
		require_once( 'screen-config.php' );
	}
	
	public function mgs_tables_admin_scripts(){
		wp_enqueue_style( 'mgs_tables_admin_css', MGS_TABLES_PLUGIN_DIR_URL.'css/admin.css' );
	}
	
	protected static function mgs_tables_admin_tab( $title, $page ) {
		if( isset($_GET['page']) ){
			$active_page = $_GET['page'];
		}
		if( $active_page==$page ){
			$link = 'javascript:void(0);';
			$active_tab = ' nav-tab-active';
		}else{
			$link = 'admin.php?page='.$page;
			$active_tab = '';
		}
		echo '<a href="'.$link.'" class="nav-tab'.$active_tab.'">'.$title.'</a>';
	}
	
	public static function footer(){
		echo '
			<div class="mgs-thanks">
				<p class="description">'.__('Gracias por elegir MGS Tables, nos esforzamos para usted.', 'mgs-tables' ).'&copy;</p>
			</div>
		';
	}
	
	public static function header() {
		echo '
			<h1>'.__('Bienvenido a MGS Tables', 'mgs-tables').'</h1>
			<div class="about-text">'.__('MGS Tables esta instalado y listo para utilizar, disfrutalo!', 'mgs-tables').'</div>
			<div class="mgs-logo"><span class="mgs-version">'.__('Versión', 'mgs-tables').' '.MGS_TABLES_VERSION.'</span></div>
			<h2 class="nav-tab-wrapper">
		';
		self::mgs_tables_admin_tab( __('Configuración', 'mgs-tables' ), 'mgs-tables-config' );
		echo '
			</h2>
		';
	}
}
new MGS_Tables_Builder_Admin();
