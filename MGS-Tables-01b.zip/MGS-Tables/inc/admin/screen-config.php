<?
global $MGS_UP;


//@include('../class/class-update.php');
//$MGS_UP = new MGS_PLG_Update();



if( isset($_POST['mgs_tables_license']) ){
	$license_key = $_POST['mgs_tables_license'];
	$val_input = $license_key;
	$MGS_UP->Set_License($license_key);
	//$lic = new MGS_PLG_Update(MGS_TABLES_VERSION, MGS_PLUGIN_REMOTE_PATH, MGS_TABLES_SLUG, $license_key, MGS_LICENSE_SERVER_URL, MGS_SPECIAL_SECRET_KEY);
	if( !$MGS_UP->active() ){
		$err_msg = $MGS_UP->err;
	}
}else{
	$MGS_UP->ValLicence();
}

?>
<div class="wrap mgs-admin-warp">
	<? MGS_Tables_Builder_Admin::header(); ?>
    
    <div class="feature-section">
        <div class="mgs-important-notice">
            <p class="about-description"><?=__('¡Gracias por elegir MGS Table! Su producto debe estar registrado para recibir todas las actualizaciones automáticas.', 'mgs-tables');?></p>
            <? if( $MGS_UP->is_licensed()!=true ){?>
            <p class="about-description"><?=__('Debera ingresar su licencia para poder utilizar esta plugin.', 'mgs-tables')?></p>
            <? }?>
        </div>
        <div class="mgs-important-notice mgs-registration-form-container">
	        <p class="about-description">
            	<?
                if( $MGS_UP->is_licensed()==true ){
					_e('Felicitaciones, su producto esta registrado.', 'mgs-tables');
				}else{
					echo sprintf(__('Ingrese su %s para completar el registro.', 'mgs-tables'), 'Licencia');
				}
				?>
             </p>    
	        <div class="mgs-registration-form">
    		    <form id="mgs_product_registration" method="post">
					<?
                    if( $MGS_UP->is_licensed() ){
                        $val_input = $MGS_UP->get_license();
						$estado = 'disabled';
                        echo '<span class="dashicons dashicons-yes mgs-icon-key"></span>';
                    }else{
						$val_input = '';
						$estado = '';
                        echo '<span class="dashicons dashicons-no mgs-icon-key"></span>';
                    }
                    ?>
		        	<input type="text" name="mgs_tables_license" id="mgs_tables_license" value="<?=$val_input?>" />
                    <p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary button-large mgs-large-button mgs-register" value="Enviar" <?=$estado?>></p>
		        </form>
        		<p class="error-invalid-token"><?=$err_msg?></p>
	        </div>
        </div>
	</div>
    

    <?php MGS_Tables_Builder_Admin::footer(); ?>
</div>