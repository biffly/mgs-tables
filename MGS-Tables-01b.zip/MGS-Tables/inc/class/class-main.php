<?PHP
if( !class_exists('MGS_Tables') ){
	class MGS_Tables{
		private static $instance;
		protected $mgs_table_up_global;
		
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new MGS_Tables();
			}
			return self::$instance;
		}

		public function __construct(){
			global $MGS_UP;
			$this->mgs_table_up_global =& $MGS_UP;
			load_theme_textdomain('mgs-forms', MGS_TABLES_PLUGIN_DIR.'/languages');
			add_shortcode( 'fusion_mgs_tables', array($this, 'fusion_mgs_tables') );
			add_action( 'wp_enqueue_scripts', array($this, 'enqueue_scripts') );
			add_filter( 'plugin_action_links_'.MGS_TABLES_BASENAME, array($this, 'mgs_tables_action_links') );
		}
		
		public function mgs_tables_action_links($links){
			$mylinks = array(
				'<a href="' . admin_url( 'admin.php?page=mgs-tables-config' ) . '">'.__('Opciones', 'mgs-tables').'</a>',
			);
			return array_merge( $links, $mylinks );
		}
		
		public function enqueue_scripts(){
			wp_enqueue_style( 'mgs-tables-css', MGS_TABLES_PLUGIN_DIR_URL.'css/estilos.css' );
			//wp_enqueue_style( 'mgs-tables-css_dataTables-bootstrap-min', MGS_TABLES_PLUGIN_DIR_URL.'css/dataTables.bootstrap.min.css' );
			
			wp_enqueue_script( 'mgs-tables-js_jquery-dataTables-min', MGS_TABLES_PLUGIN_DIR_URL.'js/jquery.dataTables.min.js', array('jquery'), '1.10.13' );
			wp_enqueue_script( 'mgs-tables-js_dataTables-bootstrap-min', MGS_TABLES_PLUGIN_DIR_URL.'js/dataTables.bootstrap.min.js', array('jquery'), '3.0.0' );
			
		}
		
		public static function activation(){
			$version_instalada = get_option( 'mgs_tables_version', 0 );
			if( MGS_TABLES_VERSION > $version_instalada ){
				update_option( 'mgs_tables_version', MGS_TABLES_VERSION, false );
			}
		}
		
		public function fusion_mgs_tables($atts){
			$args = $this->Read_Defaults_atts($atts);
			$unique_class = 'mgs-tables-' . rand();
			$html = '';
			$class_theme = '';
			if( $args['tabla_estilo']=='yes' && $args['tabla_theme']!='' ){
				$class_theme = 'mgs-theme-'.$args['tabla_theme'];
			}
			
			$html .= '<div class="mgs-tables-warpper '.$class_theme.' '.$unique_class.' '.$args['css_class'].'" id="'.$args['css_id'].'">';
			if( $args['origen']=='text' ){
				$data = $args['origen_text'];
			}elseif( $args['origen']=='csv' ){
				$data = $this->file_get_contents_utf8($args['origen_csv']);
			}elseif( $args['origen']=='gdrive' ){
				if( $this->mgs_table_up_global->is_licensed()!=true ){
					$data = '';
					$html .= 'El origen de datos "Google Drive" solo esta disponible en la versión licensiada.';
				}else{
					$data = $this->file_get_contents_utf8($args['origen_gdrive'].'&mgs_force_remote_update='.rand(9,99));
				}
			}
			$data = str_replace('"', '', $data);
			$rows = array();
			if( $data!='' ){
				$row = explode("\n",$data);
				foreach($row as $r){
					if( $r!='' ){
						$rows[] = explode(',', trim($r));
					}
				}
				
				$html .= '<table id="'.$args['id_tabla'].'" class="mgs-table '.$class_theme.'" title="'.$args['name'].'" width="'.$args['ancho_tabla'].'" border="'.$args['border_tabla'].'" cellpadding="'.$args['cellpadding_tabla'].'" cellspacing="'.$args['cellspacing_tabla'].'">';
				if( $args['header_tabla']=='yes' ){
					$html .= '<thead>';
					$html .= '<tr>';
					$i = 1;
					foreach($rows[0] as $h){
						$html .= '<th class="mgs-table-header-'.$i.'">'.$h.'</th>';
						$i++;
					}
					$html .= '</tr>';
					$html .= '</thead>';
				}
				$html .= '<tbody>';
				
				$tr_class = 'mgs-even';
				$rn = 1;
				foreach($rows as $k=>$row){
					if( $args['header_tabla']=='yes' && $k==0 ) continue;
					$html .= '<tr class="'.$tr_class.' mgs-tables-row-'.$rn.'">';
					$i = 1;
					foreach( $row as $r ){
						$html .= '<td class="mgs-tables-col-'.$i.'">'.$r.'</td>';
						$i++;
					}
					$html .= '</tr>';
					$tr_class = ( $tr_class=='mgs-even' ) ? 'mgs-odd' : 'mgs-even';
					$rn++;
				}
				$html .= '</tbody>';
				$html .= '</table>';
				
				if( $args['datatables_tabla']=='yes' ){
					$html .= '
						<script>
							jQuery("#'.$args['id_tabla'].'").DataTable({
								"language" : { "url" : "'.MGS_TABLES_PLUGIN_DIR_URL.'languages/'.get_locale().'.json" }, ';
					if( $args['datatables_cambio_largo_pagina']=='no' ) $html .= '"bLengthChange" : false, ';
					if( $args['datatables_largo_pagina']!='' && $args['datatables_cambio_largo_pagina']=='no') $html .= '"pageLength" : '.$args['datatables_largo_pagina'].', ';
					if( $args['datatables_buscador']=='no' ) $html .= '"bFilter": false, ';
					if( $args['datatables_info_pie']=='no' ) $html .= '"bInfo": false, ';
					$html .= '
							});
						</script>
					';
				}
				
			}else{
				$html .= '<p><strong>'.__('Origen de datos no encontrado.', 'mgs-tables').'</strong></p>';
			}
			
			/*	debug	*/
			if( MGS_TABLES_DEBUG ){
				$html .= '<pre>';
				$html .= print_r($args, true);
				$html .= '</pre>';
				$html .= 'Locale blog: '.get_locale().'<br>';
			}
			/*	-----	*/
			
			if( $this->mgs_table_up_global->is_licensed()!=true ){
				$html .= '<div class="mgs-copy">Powered by <a href="http://www.marceloscenna.com.ar/" target="_blank">Marcelo Scenna</a></div>';
			}
			
			$html .= '</div>';
			return $html;
			
		}
		
		public function Read_Defaults_atts($args){
			$defaults = array(
				'name'								=> '',
				'origen'							=> ( $args['origen']!='' )							? $args['origen']											: 'text',
				'origen_csv'						=> ( $args['origen_csv']!='' )						? $args['origen_csv']										: '0',
				'origen_text'						=> ( $args['origen_text']!='' )						? $args['origen_text']										: '0',
				'origen_gdrive'						=> ( $args['origen_gdrive']!='' )					? $args['origen_gdrive']									: '0',
				'css_class'							=> '',
				'css_id'							=> '',
					
				'header_tabla'						=> ( $args['header_tabla']!='' )					? strtolower($args['header_tabla'])							: 'yes',
				'tabla_estilo'						=> ( $args['tabla_estilo']!='' )					? strtolower($args['tabla_estilo'])							: 'no',
				'tabla_theme'						=> ( $args['tabla_theme']!='' )						? strtolower($args['tabla_theme'])							: 'default',
					
				'datatables_tabla'					=> ( $args['datatables_tabla']!='')					? strtolower($args['datatables_tabla'])						: 'no',
				'id_tabla'							=> '',
				'datatables_cambio_largo_pagina'	=> ( $args['datatables_cambio_largo_pagina']!='' )	? strtolower($args['datatables_cambio_largo_pagina'])		: 'no',
				'datatables_largo_pagina'			=> ( $args['datatables_largo_pagina']!='' )			? strtolower($args['datatables_largo_pagina'])				: '20',
				'datatables_buscador'		 		=> ( $args['datatables_buscador']!='' )				? strtolower($args['datatables_buscador'])					: 'no',
				'datatables_info_pie'		 		=> ( $args['datatables_info_pie']!='' )				? strtolower($args['datatables_info_pie'])					: 'no',
				
				/*'ancho_tabla'				=> ( $args['ancho_tabla']!='' )					? strtolower($args['ancho_tabla'])					: '100%',
				'border_tabla'				=> ( $args['border_tabla']!='' )				? strtolower($args['border_tabla'])					: '1',
				'cellpadding_tabla'			=> ( $args['cellpadding_tabla']!='' )			? strtolower($args['cellpadding_tabla'])			: '2',
				'cellspacing_tabla'			=> ( $args['cellspacing_tabla']!='' )			? strtolower($args['cellspacing_tabla'])			: '3',*/
			);
			
			if( !$args ){
				$args = array();
			}
			$args = shortcode_atts( $defaults, $args );
			foreach( $args as $key => $value ){
				if( '' === $value || '|' === $value ){
					$args[ $key ] = $defaults[ $key ];
				}
			}
			
			if( $args['datatables_tabla']=='yes' && $args['id_tabla']=='' ) $args['datatables_tabla'] = 'no';
			
			return $args;
		}
		
		
		private function file_get_contents_utf8($fn) {
			$content = file_get_contents($fn);
			return mb_convert_encoding($content, 'UTF-8', mb_detect_encoding($content, 'UTF-8, ISO-8859-1', true));
		}		
	}	
}