<?
global $mgs_tables_options;
$mgs_tables_options = array(
	'name'          				=> __( 'MGS Tables', 'mgs-tables' ),
	'shortcode'     				=> 'fusion_mgs_tables',
	'icon'          				=> 'fa fa-table',			
	'params'        => array(
		/*	ID	*/
		array(
			'type'        	=> 'textfield',
			'heading'     	=> __('Nombre', 'mgs-tables' ),
			'description' 	=> __( 'Nombre descriptivo de la tabla', 'mgs-tables' ),
			'param_name'  	=> 'name',
			'value'       	=> '',
			'placeholder' 	=> true,
		),
		/*	origen	*/
		array(
			'type'			=> 'select',
			'heading'		=> __('Origen de datos', 'mgs-tables'),
			'description'	=> __('Fuente que se utilizara para tomar los datos que rellenaran la tabla.', 'mgs-tables'),
			'param_name'	=> 'origen',
			'value'			=> array(
				__('Texto', 'mgs-tables')			=> 'text',
				__('Archivo CSV', 'mgs-tables')		=> 'csv',
				__('Google Drive', 'mgs-tables')	=> 'gdrive',
			),
			'default'		=> 'text'
		),
		
		/*	origen text	*/
		array(
			'type'        => 'textarea',
			'heading'     => __( 'Contenido', 'mgs-tables' ),
			'description' => __( 'Contenido de la tabla, el mismo debera ser pegado en formato CSV con las cabeceras y codificación UTF8.', 'mgs-tables' ),
			'param_name'  => 'origen_text',
			'value'       => '',
			'dependency'  => array(
				array(
					'element'  => 'origen',
					'value'    => 'text',
					'operator' => '==',
				),
			)
		),
		/*	origen csv	*/
		array(
			'type'			=> 'uploadfile',
			'heading'     	=> __('Archivo', 'mgs-tables' ),
			'description' 	=> __('Seleccione un archivo del tipo CSV, requerde que el mismo debera tener codificación UTF8', 'mgs-tables' ),
			'param_name'  	=> 'origen_csv',
			'value'       	=> '',
			'dependency'  => array(
				array(
					'element'  => 'origen',
					'value'    => 'csv',
					'operator' => '==',
				),
			)
		),
		/*	origen google drive	*/
		array(
			'type'        	=> 'textfield',
			'heading'     	=> __('Google drive csv', 'mgs-tables' ),
			'description' 	=> __( 'URL de su planilla de cálculos publicada en la web como CSV. <a href="http://66.7.220.112/~marceloscenna/como-utilizar-google-drive-como-origen-de-datos/" target="_blank">Como?</a>', 'mgs-tables' ),
			'param_name'  	=> 'origen_gdrive',
			'value'       	=> '',
			'dependency'  => array(
				array(
					'element'  => 'origen',
					'value'    => 'gdrive',
					'operator' => '==',
				),
			)
		),
		
		
		array(
			'type'        	=> 'textfield',
			'heading'     	=> __('CSS Class', 'mgs-tables' ),
			'description' 	=> __( 'Agregar una clase css al contenedor del elemento.', 'mgs-tables' ),
			'param_name'  	=> 'css_class',
			'placeholder' 	=> true,
		),
		array(
			'type'        	=> 'textfield',
			'heading'     	=> __('CSS ID', 'mgs-tables' ),
			'description' 	=> __( 'Agregar una ID al contenedor del elemento.', 'mgs-tables' ),
			'param_name'  	=> 'css_id',
			'placeholder' 	=> true,
		),
		
		/*	opciones */
		array(
			'type'        	=> 'radio_button_set',
			'heading'     	=> __( 'Cabecera', 'mgs-tables' ),
			'description' 	=> __( 'Mostrar cabecera? Se tomara la primera linea del CSV como tal.', 'mgs-tables' ),
			'param_name'  	=> 'header_tabla',
			'default'     	=> 'yes',
			'value'       	=> array(
				__( 'Si', 'mgs-tables' )	=> 'yes',
				__( 'No', 'mgs-tables' )	=> 'no',
			),
			'group'			=>	__('Opciones', 'mgs-tables'),
		),
		array(
			'type'        	=> 'radio_button_set',
			'heading'     	=> __( 'Estilo', 'mgs-tables' ),
			'description' 	=> __( 'Aplicar algun estilo predefinido?.', 'mgs-tables' ),
			'param_name'  	=> 'tabla_estilo',
			'default'     	=> 'no',
			'value'       	=> array(
				__( 'Si', 'mgs-tables' )	=> 'yes',
				__( 'No', 'mgs-tables' )	=> 'no',
			),
			'group'			=>	__('Opciones', 'mgs-tables'),
		),
		array(
			'type'			=> 'select',
			'heading'		=> __('Estilos', 'mgs-tables'),
			'description'	=> __('Conbinaciones predefinidas de estilos y colores. Podra cambiarlas agregando su CSS.', 'mgs-tables'),
			'param_name'	=> 'tabla_theme',
			'value'			=> array(
				__('Por defecto', 'mgs-tables')			=> 'default',
				__('Claro', 'mgs-tables')				=> 'claro',
				__('Oscuro', 'mgs-tables')				=> 'oscuro',

			),
			'default'		=> 'default',
			'group'			=>	__('Opciones', 'mgs-tables'),
			'dependency'  => array(
				array(
					'element'  => 'tabla_estilo',
					'value'    => 'yes',
					'operator' => '==',
				),
			)
		),
		
		/*	DataTables	*/
		array(
			'type'        	=> 'radio_button_set',
			'heading'     	=> __( 'Data Tables', 'mgs-tables' ),
			'description' 	=> __( 'Activar datatables en esta tabla?. DataTables permite paginar, ordenar y filtrar el contenido de una tabla. Debera especificar un ID en forma obligatoria.', 'mgs-tables' ),
			'param_name'  	=> 'datatables_tabla',
			'default'     	=> 'no',
			'value'       	=> array(
				__( 'Si', 'mgs-tables' )	=> 'yes',
				__( 'No', 'mgs-tables' )	=> 'no',
			),
			'group'			=>	__('DataTables', 'mgs-tables'),
		),
		array(
			'type'        	=> 'textfield',
			'heading'     	=> __('ID tabla', 'mgs-tables' ),
			'description' 	=> __( 'Identificador de la tabla.', 'mgs-tables' ),
			'param_name'  	=> 'id_tabla',
			'placeholder' 	=> true,
			'group'			=> __('DataTables', 'mgs-tables'),
			'dependency'  => array(
				array(
					'element'  => 'datatables_tabla',
					'value'    => 'yes',
					'operator' => '==',
				),
			)
		),
		array(
			'type'        	=> 'radio_button_set',
			'heading'     	=> __( 'Activar largo de pagina?', 'mgs-tables' ),
			'description' 	=> __( 'Desea mostrar un desplegable con la opción de cambiar la cantidad de registros por pagina que se muestran?', 'mgs-tables' ),
			'param_name'  	=> 'datatables_cambio_largo_pagina',
			'default'     	=> 'yes',
			'value'       	=> array(
				__( 'Si', 'mgs-tables' )	=> 'yes',
				__( 'No', 'mgs-tables' )	=> 'no',
			),
			'group'			=>	__('DataTables', 'mgs-tables'),
			'dependency'  => array(
				array(
					'element'  => 'datatables_tabla',
					'value'    => 'yes',
					'operator' => '==',
				),
			)
		),
		array(
			'type'        	=> 'textfield',
			'heading'     	=> __('Cantidad de registros', 'mgs-tables' ),
			'description' 	=> __( 'Cantidad de registros que se muestran por cada pagina.', 'mgs-tables' ),
			'param_name'  	=> 'datatables_largo_pagina',
			'placeholder' 	=> true,
			'group'			=> __('DataTables', 'mgs-tables'),
			'dependency'  => array(
				array(
					'element'  => 'datatables_tabla',
					'value'    => 'yes',
					'operator' => '==',
				),
				array(
					'element'  => 'datatables_cambio_largo_pagina',
					'value'    => 'yes',
					'operator' => '!=',
				)
			)
		),
		array(
			'type'        	=> 'radio_button_set',
			'heading'     	=> __( 'Activar buscador?', 'mgs-tables' ),
			'description' 	=> __( 'Desea activar la opcion dinamica de busqueda dentro de los registros de la tabla?', 'mgs-tables' ),
			'param_name'  	=> 'datatables_buscador',
			'default'     	=> 'no',
			'value'       	=> array(
				__( 'Si', 'mgs-tables' )	=> 'yes',
				__( 'No', 'mgs-tables' )	=> 'no',
			),
			'group'			=>	__('DataTables', 'mgs-tables'),
			'dependency'  => array(
				array(
					'element'  => 'datatables_tabla',
					'value'    => 'yes',
					'operator' => '==',
				),
			)
		),
		array(
			'type'        	=> 'radio_button_set',
			'heading'     	=> __( 'Info de tabla?', 'mgs-tables' ),
			'description' 	=> __( 'Muestra en el footer de la tabla la cantidad total de registros y en que pagina se encuentra actualmente.', 'mgs-tables' ),
			'param_name'  	=> 'datatables_info_pie',
			'default'     	=> 'no',
			'value'       	=> array(
				__( 'Si', 'mgs-tables' )	=> 'yes',
				__( 'No', 'mgs-tables' )	=> 'no',
			),
			'group'			=>	__('DataTables', 'mgs-tables'),
			'dependency'  => array(
				array(
					'element'  => 'datatables_tabla',
					'value'    => 'yes',
					'operator' => '==',
				),
			)
		),
	),
);

function mgs_tables_addon_TinyMCE_registre_buttons($buttons){
	array_push($buttons, 'separator', 'mgs_tables_cmd_id' );
	return $buttons;
}

function mgs_tables_addon_TinyMCE_registre_javascript($plugin_array){
	$plugin_array['mgs_tables_TinyMCE'] = MGS_TABLES_PLUGIN_DIR_URL.'/js/editor.js';
	return $plugin_array;
}

function mgs_tables_print_scripts(){
	if( session_id()=='' ) @session_start(); 
	global $post;
	global $mgs_tables_options;
	global $MGS_UP;
	$plg_options = array(
		'plg_url'		=> MGS_TABLES_PLUGIN_DIR_URL,
		'edit_posts'	=> current_user_can('edit_posts'),
		'edit_pages'	=> current_user_can('edit_pages'),
		'rich_editing'	=> get_user_option('rich_editing')
	);
	if( is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'fusion_mgs_tables') ){
		$plg_options['post_id'] = $post->ID;
		$plg_options['has_mgs_tables'] = true;
		$plg_options['mgs_tables_options'] = $mgs_tables_options;
	}
	
	$plg_options['licence'] = $MGS_UP->is_licensed();
	
	$_SESSION['mgs_tables_plugin_option'] = $plg_options;
	
?>
<script type="text/javascript">
  var mgs_tables_plugin_option = <?php echo json_encode($plg_options); ?>;
</script>
<?php
}