/*https://core.trac.wordpress.org/browser/tags/4.4.2/src/wp-includes/js/tinymce/plugins/wpgallery/plugin.js*/
(function() {
	tinymce.create("tinymce.plugins.mgs_tables_TinyMCE", {
        init : function(editor, url) {
            editor.addButton("mgs_tables_cmd_id", {
                title	: "MGS Tables",
                cmd		: "mgs_tables_command",
                icon	: "fa-table"
            });
			
            editor.addCommand("mgs_tables_command", function(){
				if( mgs_tables_plugin_option.licence!=true ){
					tinyMCE.activeEditor.windowManager.alert('Ingrese su licencia para activar.');
				}else{
					editor.windowManager.open({
						// Modal settings
						file	: url + '/editor.php?action=new&plg_url='+window.encodeURIComponent(mgs_tables_plugin_option.plg_url),
						title	: 'MGS Tables',
						width	: jQuery(window).width() * 0.7,
						height	: (jQuery(window).height() - 36 - 50) * 0.7,
						inline	: 1,
						id		: 'mgs-tables-dialog',
						buttons	: [
							{
								text	: 'Agregar tabla',
								id		: 'plugin-slug-button-insert',
								class	: 'insert',
								onclick	: function(e){
									var attr = top.tinymce.activeEditor.d;
									var new_content = '[fusion_mgs_tables ';
									var full_content = tinyMCE.activeEditor.getContent();
									Object.keys(attr).map(function(objectKey, index) {
										var value = attr[objectKey];
										new_content += objectKey+'="'+value+'" ';
									});
									new_content += '/]';
									//full_content = full_content.replace(FindShortcode(node), content);
									//tinyMCE.activeEditor.setContent(full_content);
									tinymce.activeEditor.execCommand('mceInsertContent', false, new_content);
									top.tinymce.activeEditor.windowManager.close();
								},
							},
							{
								text	: 'Cancelar',
								id		: 'plugin-slug-button-cancel',
								onclick	: 'close'
							}
						],
					});
				}
            });
			
			editor.on('BeforeSetContent', function(event){
				event.content = replaceMgsTablesShortcodes(event.content);
			});
			
			editor.on('PostProcess', function(event){
				if( event.get ){
					event.content = restoreMgsTablesShortcodes(event.content);
				}
			});
			
			editor.on('mouseup', function(event){
				var dom = editor.dom, node = event.target;
				if( node.nodeName==='I' ){
					var parent = node.parentNode.parentNode.parentNode;
					if( dom.getAttrib(parent, 'data-mgs-table') && event.button!==2 ){
						if( dom.getAttrib(node, 'data-mgs-acction')=='edit' ){
							if( mgs_tables_plugin_option.licence!=true ){
								tinyMCE.activeEditor.windowManager.alert('Ingrese su licencia para activar.');
							}else{
								editTable(parent);
							}
						}
						if( dom.getAttrib(node, 'data-mgs-acction')=='delete' ){
							if( mgs_tables_plugin_option.licence!=true ){
								tinyMCE.activeEditor.windowManager.alert('Ingrese su licencia para activar.');
							}else{
								deleteTable(parent);
							}
						}
					}
				}
			});
			
			function deleteTable(node){
				if( editor.dom.hasClass(node, 'mgs_tables_block') ){
					var full_content = tinyMCE.activeEditor.getContent();
					var content = '';
					full_content = full_content.replace(FindShortcode(node), content);
					tinyMCE.activeEditor.setContent(full_content);
				}
			}
			
			function editTable(node){
				var table, frame, data;
				data = editor.dom.getAttrib(node, 'data-mgs-table');
				if( editor.dom.hasClass(node, 'mgs_tables_block') ){
					editor.windowManager.open({
						file	: url + '/editor.php?action=edit&data='+data+'&plg_url='+window.encodeURIComponent(mgs_tables_plugin_option.plg_url),
						title	: 'MGS Tables',
						width	: jQuery(window).width() * 0.7,
						height	: (jQuery(window).height() - 36 - 50) * 0.7,
						inline	: 1,
						id		: 'mgs-tables-dialog',
						buttons	: [
							{
								text	: 'Actualizar',
								id		: 'plugin-slug-button-insert',
								class	: 'insert',
								onclick	: function(e){
									var attr = top.tinymce.activeEditor.d;
									var content = '[fusion_mgs_tables ';
									var full_content = tinyMCE.activeEditor.getContent();
									Object.keys(attr).map(function(objectKey, index) {
										var value = attr[objectKey];
										content += objectKey+'="'+value+'" ';
									});
									content += '/]';
									full_content = full_content.replace(FindShortcode(node), content);
									tinyMCE.activeEditor.setContent(full_content);
									top.tinymce.activeEditor.windowManager.close();
								},
							},
							{
								text	: 'Cancelar',
								id		: 'plugin-slug-button-cancel',
								onclick	: 'close'
							},
						],
					});
				}else{
					tinyMCE.activeEditor.windowManager.alert('No se selecciono una tabla valida.');
				}
			}

        },

        createControl : function(n, cm) {
            return null;
        },

        getInfo : function() {
            return {
                longname	: "Agregar MGS Tables",
                author		: "Marcelo Scenna",
                version		: "1"
            };
        }
    });
	
	function FindShortcode(node){
		const regex = /data-mgs-table=\"[^\"]+\"/gm;
		var s_node = node.outerHTML;
		var x = s_node.match(regex);
		x.map(function(item){
			new_item = window.decodeURIComponent(item).replace(/^(data-mgs-table=")/, '');
			new_item = window.decodeURIComponent(new_item).replace(/(")$/, '');
		});
		if( x ) return new_item;
		return;
	}
	
	function restoreMgsTablesShortcodes(content){
		const regex = /data-mgs-table=\"[^\"]+\"/gm;
		var x = content.match(regex);
		jqs = jQuery(content);
		ed = jQuery('<p>').append(jqs);
		
		x.map(function(item){
			new_item = window.decodeURIComponent(item).replace(/^(data-mgs-table=")/, '');
			new_item = window.decodeURIComponent(new_item).replace(/(")$/, '');
			ed.find('.mgs_module_block:first').replaceWith(new_item.trim());
		});
		if( x ) return ed.html();
		return;
	}
	
	function replaceMgsTablesShortcodes(content){
		return content.replace(/\[fusion_mgs_tables([^\]]*)\]/g, function(match){
			return html('mgs_tables_block', match);
		});
	}
	
	function html(cls, data){
		data = window.encodeURIComponent(data);
		h  = '<div class="mgs_module_block '+cls+'" data-mgs-table="'+data+'">';
			h += '<div class="mgs-builder-module-controls-container">';
				h += '<div class="mgs-builder-controls">';
					h += '&nbsp;';
					h += '<i class="mgs-builder-cmd mgs_tables_block_cmd fa fa-pencil" data-mgs-acction="edit"></i>';
					h += '<i class="mgs-builder-cmd mgs_tables_block_cmd fa fa-trash-o" data-mgs-acction="delete"></i>';
				h += '</div>';
			h += '</div>';
			h += '<div class="mgs-builder-module-preview">';
				h += '<div class="mgs_module_block_preview ">';
					h += '<h4 class="mgs_module_title"><i class="mgs-module-icon fa fa-table"></i>MGS Tables</h4>';
				h += '</div>';
			h += '</div>';
		h += '</div>';
		return h;
	}

    tinymce.PluginManager.add("mgs_tables_TinyMCE", tinymce.plugins.mgs_tables_TinyMCE);
})();