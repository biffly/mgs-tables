<?
if( session_id()=='' ) session_start();
$map = $_SESSION['mgs_tables_plugin_option']['mgs_tables_options']['params'];
$plg_url = $_SESSION['mgs_tables_plugin_option']['plg_url'];
$licenced = $_SESSION['mgs_tables_plugin_option']['licence'];
$data = urldecode($_GET['data']);
$attr = array();
$content = preg_match_all('/([^ ]*)=(\'([^\']*)\'|\"([^\"]*)\"|([^ ]*))/', trim($data), $c);
list($dummy, $keys, $values) = array_values($c);

foreach( $dummy as $d){
	list($k, $v) = explode('=', $d, 2);
	$attr[$k] = trim($v, '"');
}

$grupos = array();

foreach( $map as $e ){
	if( isset($e['group']) ){
		// grp especifico
		$grupos[$e['group']][] = $e;
	}else{
		//grp default
		$grupos['default'][] = $e;
	}
}


function build_element($e, $attr){
	$html = '<div class="form-group element-grp-'.$e['param_name'].'">';
	$html .= '<label for="'.$e['param_name'].'" class="col-xs-2 control-label">'.$e['heading'].'</label>';
	$html .= Make_element($e, $attr);
	$html .= '</div>';
	return $html;
}

function Make_element($e, $attr){
	$html = '';
	switch ($e['type']){
		case 'textfield':
			$palceholder = $e['default'];
			$value = ( $_GET['action']=='edit' ) ? $attr[$e['param_name']] : $e['default'];
			$html = '<div class="col-xs-10">';
			$html .= '<input type="text" class="form-control ele-'.$e['param_name'].' mgs-admin-element" id="'.$e['param_name'].'" value="'.$value.'" ';
			if( $e['placeholder']==1 ) $html .= 'placeholder="'.$palceholder.'"';
			$html .= build_dependency($e);
			$html .= '>';
			$html .= '<span id="helpBlock-'.$e['param_name'].'" class="help-block">'.$e['description'].'</span>';
			$html .= '</div>';
			break;
		case 'select':
			$value = ( $_GET['action']=='edit' ) ? $attr[$e['param_name']] : $e['default'];
			$html = '<div class="col-xs-10">';
			$html .= '<select class="form-control ele-'.$e['param_name'].'  mgs-admin-element" id="'.$e['param_name'].'" ';
			$html .= build_dependency($e);
			$html .= '>';
			foreach($e['value'] as $k=>$v){
				$selected = ( $v==$value ) ? 'selected' : '';
				$html .= '<option value="'.$v.'" '.$selected.'>'.$k.'</option>';
			}
			$html .= '</select>';
			$html .= '<span id="helpBlock-'.$e['param_name'].'" class="help-block">'.$e['description'].'</span>';
			$html .= '</div>';
			break;
		case 'textarea':
			$value = ( $_GET['action']=='edit' ) ? $attr[$e['param_name']] : $e['default'];
			$html = '<div class="col-xs-10">';
			$html .= '<textarea class="form-control ele-'.$e['param_name'].'  mgs-admin-element" id="'.$e['param_name'].'" rows="5" ';
			$html .= build_dependency($e);
			$html .= '>';
			$html .= $value;
			$html .= '</textarea>';
			$html .= '<span id="helpBlock-'.$e['param_name'].'" class="help-block">'.$e['description'].'</span>';
			$html .= '</div>';
			break;
		case 'uploadfile':
			$value = ( $_GET['action']=='edit' ) ? $attr[$e['param_name']] : '';
			$html = '<div class="col-xs-10">';
			$html .= '<input type="text" class="form-control ele-'.$e['param_name'].'  mgs-admin-element" id="'.$e['param_name'].'" value="'.$value.'" ';
			$html .= build_dependency($e);
			$html .= '>';
			$html .= '<span id="helpBlock-'.$e['param_name'].'" class="help-block">'.$e['description'].'</span>';
			$html .= '</div>';
			break;
		case 'radio_button_set';
			$value = ( $_GET['action']=='edit' ) ? $attr[$e['param_name']] : $e['default'];
			$html = '<div class="col-xs-10">';
			$checked = ( $value=='yes' ) ? 'checked' : '';
			$text_on = array_search ('yes', $e['value']);
			$text_off = array_search ('no', $e['value']);
			$html .= '<input type="checkbox" class="ele-'.$e['param_name'].' bootstrapSwitch  mgs-admin-element" name="'.$e['param_name'].'" id="'.$e['param_name'].'" value="yes" '.$checked.' data-on-text="'.$text_on.'" data-off-text="'.$text_off.'" ';
			$html .= build_dependency($e);
			$html .= '>';
			$html .= '<span id="helpBlock-'.$e['param_name'].'" class="help-block">'.$e['description'].'</span>';
			$html .= '</div>';
			break;
	}
	return $html;
}

function build_dependency($e){
	$html = '';
	if( isset($e['dependency']) ){
		if( count($e['dependency'])>1 ){
			foreach($e['dependency'] as $d){
				$dde[] = trim($d['element']);
				$ddo[] = trim($d['operator']);
				$ddv[] = trim($d['value']);
			}
			//$dde = '[\"'.implode('\",\"',$dde).'\"]';
			$dde = urlencode(json_encode($dde));
			$ddo = urlencode(json_encode($ddo));
			$ddv = urlencode(json_encode($ddv));
			$ddt = 'multiple';
		}else{
			$dde = $e['dependency'][0]['element'];
			$ddo = $e['dependency'][0]['operator'];
			$ddv = $e['dependency'][0]['value'];
			$ddt = 'single';
		}
		$html .= 'data-dependency-element="'.$dde.'" ';
		$html .= 'data-dependency-operator="'.$ddo.'" ';
		$html .= 'data-dependency-value="'.$ddv.'" ';
		$html .= 'data-dependency-type="'.$ddt.'" ';
	}
	return $html;
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

<link rel="stylesheet" type="text/css" href="<?=$_GET['plg_url']?>css/bootstrap-switch.min.css">
<script type="text/javascript" src="<?=$_GET['plg_url']?>js/bootstrap-switch.min.js"></script>


<div class="container-fluid" style="padding:15px">
	<div class="row">
    	<div class="col-xs-12">
        	<form class="form-horizontal">
            	<? if( $licenced ){		//licenciado??>
                    <ul class="nav nav-tabs" role="tablist">
                    <?
                    foreach($grupos as $k=>$grupo){
                        $class = ($k=='default')?'active':'';
                        $label = ($k=='default')?'General':$k;
                    ?>
                        <li role="presentation" class="<?=$class?>"><a href="#<?=$k?>" aria-controls="<?=$k?>" role="tab" data-toggle="tab"><?=$label?></a></li>
                    <? }?>
                    </ul>
                    <div class="tab-content" style="padding:20px;">
                    <?
                    foreach($grupos as $k=>$grupo){
                        $class = ($k=='default')?'active':'';
                    ?>
                        <div role="tabpanel" class="tab-pane <?=$class?>" id="<?=$k?>">
                        <?
                        foreach($grupo as $elem){
                            echo build_element($elem, $attr);
                        }
                        ?>
                        </div>
                    <? }?>
                    <script>
                        $(document).ready(function() {
                            //console.clear();
                            $(".bootstrapSwitch").bootstrapSwitch();
                            Check_Dependencys();
                            
                            $('.mgs-admin-element').on('change blur click keyup', function(){ Check_Dependencys(); })
                            $('.bootstrapSwitch').on('switchChange.bootstrapSwitch', function(event, state){ Check_Dependencys(); });
                            
                            function Check_Dependencys(){
                                //console.log(parent.tinymce.activeEditor);
                                parent.tinymce.activeEditor.d = [];
                                $('.mgs-admin-element').each(function(index, element) {
                                    
                                    if( $(this).is(":checkbox") ){
                                        parent.tinymce.activeEditor.d[$(this).attr('id')] = ( $(this).is(':checked') ) ? 'yes' : 'no';
                                    }else{
                                        parent.tinymce.activeEditor.d[$(this).attr('id')] = $(this).val();
                                    }
                                    
                                    if( $(this).data('dependency-element') ){
                                        var dd_test; var dd_operator; var dd_value; var dd_element;
                                        if( $(this).data('dependency-type')=='single' ){
                                            dd_test = $(this).data('dependency-element');
                                            dd_operator = $(this).data('dependency-operator');
                                            dd_value = $(this).data('dependency-value');
                                            dd_element = $(this).attr('id');
                                            if( $('.ele-'+dd_test).is(":checkbox") ){	//es checkbox
                                                if( dd_operator=='==' ){	//operador igual
                                                    if( $('.ele-'+dd_test+':checked').val() == dd_value ){
                                                        $('.element-grp-'+dd_element).show();
                                                    }else{
                                                        $('.element-grp-'+dd_element).hide();
                                                    }
                                                }
                                            }else{		// no es checkbox
                                                if( dd_operator=='==' ){	//operador ==
                                                    if( $('.ele-'+dd_test).val() == dd_value ){
                                                        $('.element-grp-'+dd_element).show();
                                                    }else{
                                                        $('.element-grp-'+dd_element).hide();
                                                    }
                                                }
                                            }
                                        }else{
                                            dd_test = JSON.parse(decodeURIComponent($(this).data('dependency-element')));
                                            dd_operator = JSON.parse(decodeURIComponent($(this).data('dependency-operator')));
                                            dd_value = JSON.parse(decodeURIComponent($(this).data('dependency-value')));
                                            dd_element = $(this).attr('id');
                                            var test = false;
                                            $.each(dd_test, function(k, v){
                                                if( $('.ele-'+v).is(":checkbox") ){	//es checkbox
                                                    if( dd_operator[k]=='==' ){		// operador IGUAL
                                                        if( $('.ele-'+v+':checked').val() == dd_value[k] ){
                                                            $('.element-grp-'+dd_element).show();
                                                        }else{
                                                            $('.element-grp-'+dd_element).hide();
    
                                                        }
                                                    }else if( dd_operator[k]=='!=' ){		// operador DISTINTO
                                                        if( $('.ele-'+v+':checked').val() != dd_value[k] ){
                                                            $('.element-grp-'+dd_element).show();
    
                                                        }else{
                                                            $('.element-grp-'+dd_element).hide();
                                                        }
                                                    }
                                                }else{		//no es checkbox
                                                    if( dd_operator[k]=='==' ){	//operador IGUAL
                                                        if( $('.ele-'+v).val() == dd_value[k] ){
                                                            $('.element-grp-'+dd_element).show();
                                                        }else{
                                                            $('.element-grp-'+dd_element).hide();
                                                        }
                                                    }
                                                }
                                            });
                                        }
                                    }
                                });
                                console.log(parent.tinymce.activeEditor.d);
                            }
                        });
                    </script>
                	</div>
				<? }else{?>
                	<h2 align="center" style="color:#f00;">Ingrese su licencia para activar este plugin.</h2>
                <? }?>
			</form>
		</div>  
	</div>
</div>