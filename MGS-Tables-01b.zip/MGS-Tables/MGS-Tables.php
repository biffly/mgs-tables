<?
/*
Plugin Name: MGS Tables
Plugin URI: http://www.marceloscenna.com.ar/categoria-producto/wordpress/mgs-tables/
Description: Importa archivos CSV y crea tablas en forma dinamica y facil.
Version: 0.1.b
Author: Marcelo Scenna
Author URI: http://www.marceloscenna.com.ar
Text Domain: mgs-tables
*/

if( !defined('ABSPATH') ){ exit; }

error_reporting(E_ALL & ~E_NOTICE);

if( !defined('MGS_TABLES_BASENAME') )		define( 'MGS_TABLES_BASENAME', plugin_basename(__FILE__) );
if( !defined('MGS_TABLES_PLUGIN_DIR') ) 	define( 'MGS_TABLES_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
if( !defined('MGS_TABLES_PLUGIN_DIR_URL') )	define( 'MGS_TABLES_PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );
if( !defined('MGS_TABLES_VERSION') ) 		define( 'MGS_TABLES_VERSION', '0.1.b' );
if( !defined('MGS_TABLES_SLUG') )	 		define( 'MGS_TABLES_SLUG', 'MGS-Tables/MGS-Tables.php' );
if( !defined('MGS_PLUGIN_REMOTE_PATH') )	define( 'MGS_PLUGIN_REMOTE_PATH', 'http://marceloscenna.com.ar/update.php' );
if( !defined('MGS_SPECIAL_SECRET_KEY') ) 	define( 'MGS_SPECIAL_SECRET_KEY', '589b4113769878.59794845' );
if( !defined('MGS_LICENSE_SERVER_URL') )	define( 'MGS_LICENSE_SERVER_URL', 'http://marceloscenna.com.ar' );
if( !defined('MGS_ITEM_REFERENCE') )		define( 'MGS_ITEM_REFERENCE', 'MGS-TABLES' );
if( !defined('MGS_TABLES_DEBUG') )			define( 'MGS_TABLES_DEBUG', false );

global $mgs_tables_options;
global $MGS_UP;

include(MGS_TABLES_PLUGIN_DIR.'/inc/class/class-main.php');
include(MGS_TABLES_PLUGIN_DIR.'/inc/config/tables.php');
include(MGS_TABLES_PLUGIN_DIR.'/inc/admin/main.php');
include(MGS_TABLES_PLUGIN_DIR.'/inc/class/class-update.php');

register_activation_hook(__FILE__, array('MGS_Tables', 'activation'));
add_action('wp_loaded', 'MGS_Tables_addon_load', 10);

if( is_admin() ){
	add_filter('mce_external_plugins', 'mgs_tables_addon_TinyMCE_registre_javascript');
	add_action('mce_buttons', 'mgs_tables_addon_TinyMCE_registre_buttons');
	add_action('wp_print_scripts','mgs_tables_print_scripts');
	add_editor_style(MGS_TABLES_PLUGIN_DIR_URL.'css/editor.css');
	add_editor_style(MGS_TABLES_PLUGIN_DIR_URL.'css/font-awesome.min.css');
	add_action( 'admin_print_scripts', 'mgs_tables_admin_scripts');
}

function MGS_Tables_addon_load() {
	global $MGS_UP;	
	MGS_Tables::get_instance();
	$MGS_UP = new MGS_PLG_Update(MGS_TABLES_VERSION, MGS_PLUGIN_REMOTE_PATH, MGS_TABLES_SLUG, false, MGS_LICENSE_SERVER_URL, MGS_SPECIAL_SECRET_KEY);
	if( !$MGS_UP->is_licensed()==true ) add_action( 'admin_notices', 'mgs_tables_notice_not_registred' );
}

function mgs_tables_notice_not_registred(){
	$screen = get_current_screen();
	if( $screen->parent_base!='mgs-tables-config' ){
	?>
    <div class="error notice mgs-tables-error">
        <h3 style="color:#dc3232">MGS-Tables (Beta)</h3>
        <p>MGS-Tables no se encuantra registrado, debera ingresar su licencia para activarlo.</p>
        <p><a class="button button-primary button-medium" href="http://www.marceloscenna.com.ar/categoria-producto/wordpress/mgs-tables/" target="_blank">No poseo un licencia</a> <a class="button button-primary button-medium" href="<?=admin_url('admin.php?page=mgs-tables-config')?>">Ingresar mi licensia ahora.</a></p>
    </div>
    <?
	}
}

function mgs_tables_admin_scripts(){
	wp_enqueue_style( 'mgs_tables_admin_css', MGS_TABLES_PLUGIN_DIR_URL.'css/admin.css' );
}